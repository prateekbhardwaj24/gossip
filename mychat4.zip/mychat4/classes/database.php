<?php

class Database
{
    public function dbConnection(){
        $db_host = "sql202.epizy.com";
        $db_name = "epiz_26632740_mychat";
        $db_username = "epiz_26632740";
        $db_password = "Ka1WrJdtaQ5";
        
        $dsn_db = 'myslq:host='.$db_host.';dbname='.$db_name.';charset=utf8';
        try{
            $site_db = new PDO($dsn_db, $db_username, $db_password);
            $site_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $site_db;
        }
        catch (PDOException $e){
            echo $e->getMessage();
            exit;
        }
    }
}
?>
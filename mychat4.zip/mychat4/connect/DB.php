<?php

class DB{

    private static function connect(){
$pdo = new PDO('sql202.epizy.com; dbname=epiz_26632740_mychat; charset=utf8mb4', 'epiz_26632740', 'Ka1WrJdtaQ5');

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
return $pdo;
}
    public static function query($query, $params = array()){
        $statement = self::connect()->prepare($query);
        $statement->execute($params);

if(explode(' ', $query)[0] == 'SELECT'){
    $data = $statement->fetchAll();
    return $data;
}
    }
}
?>



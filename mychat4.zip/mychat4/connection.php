<?php
$con = mysqli_connect("sql202.epizy.com", "epiz_26632740", "Ka1WrJdtaQ5", "epiz_26632740_mychat") or die("connection was not establish");
?>

<?php

$hostDetails = 'sql202.epizy.com; dbname=epiz_26632740_mychat; charset=utf8mb4';
$userAdmin = 'epiz_26632740';
$pass = 'Ka1WrJdtaQ5';

try{
    $pdo = new PDO($hostDetails,$userAdmin,$pass);
} catch(PDOExecption $e){
    echo 'Connection error!' . $e->getMessage();
}

?>
 
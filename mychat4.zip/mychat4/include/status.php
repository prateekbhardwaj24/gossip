<div class="container-fluid">

	<div class="row">
		<div class="col-sm-2 sexy-boy">

		</div>
		<div class="col-sm-8">
			<div class="profile-status-write  mb-3 mt-3 pt-3">
				<div class="status-wrap">
					<div class="status-top-wrap">
						<div class="status-top">
							Create Thoughts
						</div>
					</div>

					<div class="status-med">

						<div class="status-prof-textarea">
							<textarea name="textStatus" id="statusEmoji" cols="5" rows="5" class="status align-middle" placeholder="Share your thoughts!"></textarea>
						</div>
					</div>
<!--					-->
					<div class="status-bot">
						<div class="file-upload-remIm input-restore">

							<label for="multiple_files" class="file-upload-label">
								<div class="status-bot-1">
									<img src="assets/image/photo.JPG" alt="" style="width: 20px; height: 20px; box-shadow: none;">
									<div class="status-bot-text  ml-2">Photo</div>
								</div>
							</label>
							<input type="file" name="post-file-upload" id="multiple_files" class="file-upload-input postImage" data-multiple-caption="{count} files selected" multiple="">

						</div>

					</div>
					<ul id="sortable" style="position:relative;">

					</ul>
					<div id="error_multiple_files"></div>
					
					<div class="status-share-button-wrap">

						<div class="seemore-sharebutton">

							<div class="status-share-button align-middle">
								post
							</div>
						</div>
						
					</div>
				
<!--					-->
				</div>
			</div>
		</div>
				<div class="col-sm-2"></div>
	</div>
		<div style="align-items: center; display: flex; flex-direction:column;">
		    <div id="loading">
                <div></div>
                <div></div>
		    </div>
		    <div  id="uploading"></div>
		</div>
</div>



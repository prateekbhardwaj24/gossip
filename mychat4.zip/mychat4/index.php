<?php
session_start();
require 'connect/DB.php';
require 'core/load.php';


if( isset($_POST['user_name']) && !empty($_POST['user_name'])){
// $upFirst = $_POST['first-name'];
    $user_name = $_POST['user_name'];
    $upEmailMobile = $_POST['email-mobile'];
    $upPassword = $_POST['up-password'];
    // $birthDay = $_POST['birth-day'];
    // $birthMonth = $_POST['birth-month'];
    // $birthYear = $_POST['birth-year'];
    if(!empty($_POST['gen'])){
    $upgen = $_POST['gen'];
    }
    // $birth = ''.$birthYear.'-'.$birthMonth.'-'.$birthDay.'';

    if(empty($user_name) or empty($user_name) or empty($upEmailMobile) or empty($upgen)){
        $error = 'All feilds are required';
    }else{
$user_name = $loadFromUser->checkInput($user_name);
// $last_name = $loadFromUser->checkInput($upLast);
$email_mobile = $loadFromUser->checkInput($upEmailMobile);
$password = $loadFromUser->checkInput($upPassword);
$screenName = ''.$user_name.'';
        if(DB::query('SELECT user_name FROM my_users1 WHERE user_name = :user_name', array(':user_name' => $user_name ))){
$screenRand = rand();
            $userLink = ''.$screenName.''.$screenRand.'';
        }else{
            $userLink = $screenName;
        }
if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email_mobile)){
   if(!preg_match("^[0-9]{11}^", $email_mobile)){
       $error = 'Email id or Mobile number is not correct. Please try again.';
   }else{
     $mob = strlen((string)$email_mobile);

       if($mob > 11 || $mob < 11){
           $error = 'Mobile number is not valid';
       }else if(strlen($password) <5 || strlen($password) >= 60){
           $error = 'Password is not correct';
       }else{
           if(DB::query('SELECT mobile FROM my_users1 WHERE mobile=:mobile', array(':mobile'=>$email_mobile))){
               $error = 'Mobile number is already in use.';
           }else{
//               $tstrong = true;
               $token1 = bin2hex(openssl_random_pseudo_bytes(64));

               $user_id=$loadFromUser->create('my_users1', array('user_name'=>$user_name, 'mobile' => $email_mobile, 'user_pass'=>password_hash($password, PASSWORD_BCRYPT),'userLink'=>$userLink, 'user_gender'=>$upgen, 'token'=>$token1));

                $loadFromUser->create('profile', array('userId'=>$user_id,'user_name'=>$user_name, 'profilePic'=>'assets/image/defaultProfile.png','coverPic'=>'assets/image/defaultCover.png', 'user_gender'=>$upgen));

               $tstrong = true;
            $token = bin2hex(openssl_random_pseudo_bytes(64, $tstrong));
          $loadFromUser->create('token', array('token'=>sha1($token), 'user_id'=>$user_id));

          setcookie('FBID', $token, time()+60*60*24*7, '/', NULL, NULL, true);

          header('Location: demo.php');


           }
}
   }
}
else{
  if(!filter_var($email_mobile)){
      $error = "Invalid Email Format";
  }else if(strlen($first_name) > 20){
      $error = "Name must be between 2-20 character";
  }else if(strlen($password) <5 && strlen($password) >= 60){
      $error = "The password is either too shor or too long";
  }else{
      if((filter_var($email_mobile,FILTER_VALIDATE_EMAIL)) && $loadFromUser->checkEmail($email_mobile) === true){
          $error = "Email is already in use";
      }else{
          $token1 = bin2hex(openssl_random_pseudo_bytes(64));
         $user_id = $loadFromUser->create('my_users1', array('user_name'=>$user_name, 'user_email' => $email_mobile, 'user_pass'=>password_hash($password, PASSWORD_BCRYPT),'userLink'=>$userLink, 'user_gender'=>$upgen, 'token'=>$token1));

          $loadFromUser->create('profile', array('userId'=>$user_id,'user_name'=>$user_name, 'profilePic'=>'assets/image/defaultProfile.png','coverPic'=>'assets/image/defaultCover.png', 'gender'=>$upgen));


$tstrong = true;
$token = bin2hex(openssl_random_pseudo_bytes(64, $tstrong));
          $loadFromUser->create('token', array('token'=>sha1($token), 'user_id'=>$user_id));

          setcookie('FBID', $token, time()+60*60*24*7, '/', NULL, NULL, true);

          header('Location: demo.php');

      }
  }
}



    }
}

if(isset($_POST['in-email-mobile']) && !empty($_POST['in-email-mobile'])){
    $email_mobile = $_POST['in-email-mobile'];
    $in_pass = $_POST['in-pass'];

    if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^", $email_mobile)){
        if(!preg_match("^[0-9]{11}^", $email_mobile)){
            $error = 'Email or Phone is not correct. Please try again';
        }else{

        if(DB::query("SELECT mobile FROM my_users1 WHERE mobile = :mobile", array(':mobile'=>$email_mobile))){
            if(password_verify($in_pass, DB::query('SELECT password FROM my_users1 WHERE mobile=:mobile', array(':mobile'=>$email_mobile))[0]['password'])){

                $user_id=DB::query('SELECT user_id FROM my_users1 WHERE mobile=:mobile', array(':mobile'=>$email_mobile))[0]['user_id'];
               $tstrong = true;
$token = bin2hex(openssl_random_pseudo_bytes(64, $tstrong));
          $loadFromUser->create('token', array('token'=>sha1($token), 'user_id'=>$user_id));

          setcookie('FBID', $token, time()+60*60*24*7, '/', NULL, NULL, true);

          header('Location: demo.php');
            }else{
                $error="Password is not correct";
            }

        }else{
            $error="User hasn't found.";
        }

        }
    }else{
        if(DB::query("SELECT user_email FROM my_users1 WHERE user_email = :email", array(':email'=>$email_mobile))){
            if(password_verify($in_pass, DB::query('SELECT user_pass FROM my_users1 WHERE user_email=:email', array(':email'=>$email_mobile))[0]['user_pass'])){

                $user_id=DB::query('SELECT user_id FROM my_users1 WHERE user_email=:email', array(':email'=>$email_mobile))[0]['user_id'];
                $user_name=DB::query('SELECT user_name FROM my_users1 WHERE user_email=:email', array(':email'=>$email_mobile))[0]['user_name'];
		    $_SESSION['user_name'] = $user_name;
               $tstrong = true;
		    $token = bin2hex(openssl_random_pseudo_bytes(64, $tstrong));
          $loadFromUser->create('token', array('token'=>sha1($token), 'user_id'=>$user_id));
          $_SESSION['user_id'] = $user_id;
          $_SESSION['user_email'] = $email_mobile;
          
          setcookie('FBID', $token, time()+60*60*24*7, '/', NULL, NULL, true);

          header('Location: demo.php');
            }else{
                $error="Password is not correct";
            }

        }else{
            $error="User hasn't found.";
        }
    }
}


?>




<!DOCTYPE html>
<html lang="en">

<head>
<!--    <meta charset="UTF-8">-->
    	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <title>facebook</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</head>

<body>

    <!--    navigation bar-->

    <nav class="navbar navbar-expand d-flex" style="height: 60px; background: #f2f7fb; box-shadow: 6px 6px 10px -1px rgba(0, 0, 0, 0.15),
        -6px -6px 10px -1px rgba(255, 255, 255, 0.7);
    border: 1px solid rgba(0, 0, 0, 0);
    transition: transform 0.5s; border-radius: 8px; justify-content: space-between; align-items: center;">
        <!-- Brand -->
       <div style="width: 90px; height 60px;" class="mt-3">
           <img src="gossup.png" alt="" style="width: 100%; height: auto;">
       </div>

        <!-- Navbar links -->
        <div id="collapsibleNavbar">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="tutorial.php">Demo</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Help</a>
                </li>
              
            </ul>
        </div>
    </nav>







    <div class="main">


        <div class="header">

            <div class="web_logo">
                <img src="gos.png">

            </div>
            <div class="web_name">
                <p align="center" class="login">Login Here</p>
            </div>

            <p align="center" class="text-primary recover_msg"><?php
                  
                  if(isset($_SESSION['msg'])){
                      echo $_SESSION['msg'];
                  }
                  else{
                      echo $_SESSION['msg']= "";
                  }
                  ?>
            </p>




            <form action="index.php" method="post">
                <div class="sign-in-form">
                    <div class="mobile-input">

                        <i class="fa fa-envelope text-muted " aria-hidden="true"></i>
                        <input type="text" name="in-email-mobile" id="email-mobile" class="input-text-field" placeholder='Email'>
                    </div>
                    <div class="password-input">

                        <i class="fa fa-key text-muted" aria-hidden="true"></i>
                        <input type="password" name="in-pass" id="in-password" class="input-text-field" placeholder="Password">

                    </div>
                    <div class="login-button">
                        <input type="submit" value="Log in" class="sign-in login">
                    </div>
                    <a href="reset.php" style="text-decoration: none;">
                        <div class="forgotten-acc" align="center">Forgotten Password</div>
                    </a>
                </div>
            </form>
        </div>

        <div class="right-side">
            <div class="error">
                <?php if(!empty($error)){echo $error;} ?>
            </div>
            <div class="web_logo">
                <img src="gos.png">
            </div>
            <div class="web_name">
                <p align="center" class="login">Create Account </p>

            </div>

            <form action="index.php" method="post" name="user-sign-up">
                <div class="sign-up-form">
                    <div class="sign-up-name">
                        <i class="fa fa-user-circle-o text-muted" aria-hidden="true"></i>
                        <input type="text" name="user_name" id="user_name" class="text-field" placeholder="Username">

                    </div>
                    <div class="sign-wrap-mobile">
                        <i class="fa fa-envelope text-muted " aria-hidden="true"></i>
                        <input type="text" name="email-mobile" id="up-email" placeholder="Email" class="text-input">
                    </div>
                    <div class="sign-up-password">
                        <i class="fa fa-key text-muted" aria-hidden="true"></i>
                        <input type="password" name="up-password" id="up-password" class="text-input" placeholder="Password">
                    </div>

                    <div class="gender-wrap" align="center">
                        <input type="radio" name="gen" id="fem" value="female" class="m0">
                        <label for="fem" class="gender">Female</label>
                        <input type="radio" name="gen" id="male" value="male" class="m0">
                        <label for="male" class="gender">Male</label>
                    </div>

                    <div class="sign_button">
                        <input type="submit" value="Sign Up" class="sign-up">
                    </div>
                </div>
            </form>
        </div>

    </div>

    <script src="assets/js/jquery.js"></script>



</body>

</html>

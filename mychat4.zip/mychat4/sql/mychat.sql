-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2020 at 05:05 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mychat`
--

-- --------------------------------------------------------

--
-- Table structure for table `block`
--

CREATE TABLE `block` (
  `id` int(11) NOT NULL,
  `blockerID` int(11) DEFAULT NULL,
  `blockedID` int(11) DEFAULT NULL,
  `blockOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` int(11) NOT NULL,
  `comment_parent_id` int(11) NOT NULL,
  `commentReplyID` decimal(20,0) NOT NULL,
  `replyID` decimal(20,0) NOT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `commentOn` int(11) NOT NULL,
  `commentBy` decimal(20,0) NOT NULL,
  `commentAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` int(11) NOT NULL,
  `user_one` int(11) NOT NULL,
  `user_two` int(11) NOT NULL,
  `locker` varchar(255) NOT NULL,
  `lockpass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `friend_request`
--

CREATE TABLE `friend_request` (
  `id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `highest`
--

CREATE TABLE `highest` (
  `user_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `num` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lockerroom`
--

CREATE TABLE `lockerroom` (
  `id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `locker` varchar(255) NOT NULL,
  `lockpass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `my_users1`
--

CREATE TABLE `my_users1` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `userLink` text NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_pass` varchar(100) NOT NULL,
  `user_profile` varchar(255) NOT NULL,
  `user_country` text NOT NULL,
  `user_gender` text NOT NULL,
  `forgotten_answer` varchar(100) NOT NULL,
  `log_in` varchar(7) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `private_pass` varchar(255) NOT NULL,
  `lastseen` int(11) DEFAULT NULL,
  `last_seen` text DEFAULT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `notificationOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_name` varchar(255) NOT NULL,
  `reactType` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE `online` (
  `user_id` int(10) NOT NULL,
  `id` varchar(10) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `post` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `postBy` int(11) DEFAULT NULL,
  `sharedFrom` int(11) DEFAULT NULL,
  `shareId` int(11) DEFAULT NULL,
  `sharedBy` int(11) DEFAULT NULL,
  `postImage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `imageId` text DEFAULT NULL,
  `likesCount` int(11) DEFAULT NULL,
  `shareCount` int(11) DEFAULT NULL,
  `postedOn` timestamp NULL DEFAULT current_timestamp(),
  `shareText` text DEFAULT NULL,
  `profilePhoto` text DEFAULT NULL,
  `coverPhoto` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `currentCity` varchar(255) DEFAULT NULL,
  `shortBio` text DEFAULT NULL,
  `aboutYou` text DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `profilePic` text DEFAULT NULL,
  `coverPic` text DEFAULT NULL,
  `politicalViews` varchar(255) DEFAULT NULL,
  `religion` varchar(255) DEFAULT NULL,
  `highSchool` text DEFAULT NULL,
  `college` text DEFAULT NULL,
  `university` text DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `hometown` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `workplace` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `professional` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `otherPlace` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `socialLink` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `relationship` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `quotes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `otherName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lifeEvent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dob` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `react`
--

CREATE TABLE `react` (
  `reactID` int(11) NOT NULL,
  `reactBy` int(11) NOT NULL,
  `reactOn` int(11) NOT NULL,
  `reactCommentOn` int(11) NOT NULL,
  `reactReplyOn` int(11) NOT NULL,
  `reactType` enum('like','love','haha','wow','sad','angry') CHARACTER SET utf8 NOT NULL,
  `reactTimeOn` datetime NOT NULL,
  `status` varchar(200) DEFAULT NULL,
  `sender` int(11) NOT NULL,
  `reciever` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`id`, `token`, `user_id`) VALUES
(348, '3bee65a75af0006a63ce4dc325ae8b9ca15cb732', 102),
(349, '63ca3fbbf72c29baa2b0d71c1f3f86540cb44963', 100),
(350, '2c969d7d7344004d30c169979eeb13b2b424986a', 102),
(351, '5baa599880acbc07f85a7027b4b0050029c59dd8', 103),
(352, '13799bdd7bfaa11bfd68d161d4f1a529d1f0b93b', 102),
(353, 'b15a39a87db7a8fc3913a1476f7be668230f729a', 100),
(354, '333119f383f656453539573cbd7c5a4e04128627', 102),
(355, '1444cf71435076362d08a0ec416f287d0232c53e', 102),
(356, '4cb9464ffecbe9e92d2079d63f73739e11eeffe5', 102),
(357, '7fb826e75622a718bd51c589c7f06693f25c740f', 100),
(358, 'a3f51167575b5107d5cc9738abb9c875253d9279', 103),
(359, '3baaf4048551bfc64e2b25c7b6836bc93788e0f0', 102),
(360, 'be90b2c9b2f95ba39d7b84be6575535bb551471c', 103),
(361, 'b7bdf65320d65975cd79cb8d41e0a61fb60b2c84', 100),
(362, 'ffc93adb5c2af0eadd0f53b921ce969dd97253c2', 102),
(363, '56ebcecb93ea1a0d9baadd7cf79d4118815fe515', 103),
(364, '25bdf0a187ba922876c9ed7e1313772db539c1e9', 100),
(365, '5cdfb296bd5bd369863751122317039e5a7c4173', 102),
(366, '40d76b0d0e652338cac40eea32a777972820dc51', 100),
(367, 'b814d71b843b305808d026f17b380415ac0753d3', 102),
(368, '8a97d4120e8dc74420e5a0f1e180ace9591cff23', 100),
(369, 'eb3391e36d507f053529872a31ef927d849a9ad3', 102),
(370, '264df84965210b241460f1abd05ccdae216c05f0', 100),
(371, '24ac06c7dfdf76d2b54f625fe8336f2eeb107bcb', 102),
(372, 'dd60860ad79134a876d14908fd25175e2430d7ca', 100),
(373, 'fcd7b596a1892ce8a2deaff5f82c84fe9c4551e7', 102),
(374, '42ac0dd20085a045802f2d209e8c8f1f90d4a3d4', 100),
(375, '7fc3c5127704237e78531af333835466e85562a1', 102),
(376, '2a2dab90b4e3bfde432a74ccef808a7e0cb8c90e', 100),
(377, 'a7b8ed3d52ed21c714f81130724529c8899c980c', 102),
(378, '646a0bed67877db9b56311b03771d03dfdb4e4b0', 102),
(379, '3104b40fdf4b5ea793da9e5b168e87ca18da4931', 100),
(380, '45c582162998feadda173d3bccbb99a3f7caa4fe', 102),
(381, '5b8db516d98c75c2444b08c4f6b6ef15468fba31', 103),
(382, '579a801afcdaac227cd21fe9591a327eea131749', 100),
(383, 'b93839e1b011cbd400c24cb6a77af88fdea67a26', 102),
(384, '9cd66b9b562d1479b5c9000c8de99fff92d50119', 103),
(385, 'a76f7dddf24a7eeea57c080454ce4f28017caf2b', 102),
(386, '7de3ebb7674855366033c226fdd0229e94b5eef7', 100),
(387, 'c5c0ff1cb1ef917305cdd54b8c437a0961c451e6', 103),
(388, '09a148cdde14980a3ef199f0b34e105e04f7bc49', 102),
(389, 'dbd200c489fc54f498fb71f775c8cf849a82ba13', 103),
(390, 'adeb56fc4fc6bc649845c17e7b7d2089dcf63d33', 100),
(391, 'cd127af6178ac6cbf83bda879b5a693778da9a28', 103),
(392, '2df530b74be05abb285c69e2559e4483b7deed60', 100),
(393, 'f5631d1501b720d7005cece16c623c6fe8d78287', 100),
(394, '0e2eb2c4e59b7ed4c3020dd647da0eb6c983ca01', 102),
(395, '5f7b9136102043a572f1e6f5e27777dbc72e275a', 103),
(396, '6152010b6c7219a99b82a47140f800f6d00e0507', 100),
(397, '9f98bba11cf679bda7f66929bd9bfb6b3cd83a56', 102),
(398, 'e1d2c0999b030c1d5c560b4a8eca017b515be0d1', 100),
(399, '5486a92ac193efcb9400bddcc1a603f57354d43e', 103),
(400, 'd59f99bff5df0a9a780a260804baf1a8ef70d03a', 102),
(401, '76ded8d4780031fa21b08a687cfa814754cafe45', 102),
(402, '1b4438cdd3930c0f6ad36f7c241e30d2f19ec860', 102),
(403, '759d3fb1051cb63dcaf38a139b771517636ffbde', 100),
(404, 'ce462a5b337a999246ef007a7a404b07f6c27d88', 103),
(405, 'e01cad397c00c2cd8b86d241b03fdd36b22699d6', 103),
(406, '50d646fc38b676330abf87d725b5d0171260e920', 102),
(407, '03f4a14b52ad40a6f8886d0d033931b872162890', 102),
(408, 'fd6148ccaa7623b6076abc08a970c1a535baa4d7', 100),
(409, '9d1e3783fd40e2e902c087692275808fe6246846', 103),
(410, 'b85d6fe6fb1e2bf14b0bbcc9b71775912afc7aae', 100),
(411, '633c398a99a74af184400a349aa3a5913045be96', 103),
(412, '017cb58cd73c3f31c7f8c413af12f1912b51e356', 102),
(413, '6d4f59f333998b43ba37e31380a7c07c7c61af63', 103),
(414, '78b2902b3b2d36779db0ec14b4eac6cd730f3bfb', 100),
(415, '482918f8ef2abb83b4e6fc3873dc62c787fc6027', 103),
(416, '63d5090e62806e4d62324d0d4ab512dc0f4d7692', 100),
(417, '9c158d064fb922289fe669a538f8d13da6cd4c21', 102),
(418, '0462914418e4fca697743360c170c294128dd8fe', 100),
(419, '56bffe212739f4588587fc0e0ea9af2cca90f2cf', 103),
(420, '78d695ebf1347fe7262509d65cffc8652a57c575', 102),
(421, 'b8a38bb9a183678549cb55f5bbe0edfab43b0e31', 103),
(422, '46688acfdc16330287682898ea8a6d29a28af67d', 100),
(423, '359544ae45797a127fe0fece669facb6a83a33ee', 103),
(424, 'b86a7147395999e57806967dc22cb5ace636bdd9', 100),
(425, 'f6227be3c9cc6ca411d7f5d97205459ff1f0fb5d', 103),
(426, 'ecde18c379ee82895036154f474480b3e358daaa', 102),
(427, '2a9581b0004fc8cf75066689f20226bc27bceb20', 100),
(428, '67373fbde517fb7729ce889b7468fce7910d3427', 103),
(429, '2425a1988d27551ed0d758e7a1999dbd97b71ebd', 102),
(430, 'b13836a42009b149928e92a7adc492a76c8e663f', 103),
(431, '31c362d311db6847fb3fb2519e0b4815c0600d7d', 102),
(432, '2810bb5d5e8199bf1323471bcb7ecbf84e00225d', 100),
(433, '121f58df78795a770361a288b3330d4050047bd5', 102),
(434, '28779ba66b91b3e76833fc1fcad604da75ad6f8f', 100),
(435, 'c06c5fecd77c436d4a2a339b9455cf0a1b06b841', 103),
(436, '31fc2f4b0bc7aba4efc287513bd38d3d0bd5521e', 103),
(437, '893b47e0142fef53a157fde2fdd24d8062229353', 102),
(438, '801947711dde2141976e03ca988ccd7bf50e5714', 100),
(439, 'cdcdf9573f9724e433c71b8976db5a6d573b4cb9', 102),
(440, '7cfb21d4bb6f9b8e444b630a0f0fa575b0465de1', 100),
(441, 'f22f9d623e4ce2d4af0427b31b6f1d607a7980b4', 103),
(442, 'be94610186deb2475dc13c2454a14b0136195ad1', 102),
(443, 'ca19d2244ad5c7b82e80bca2713f0838acd2ce8e', 100),
(444, 'ae8bee1810a3b66bde436a17b3dcdc7c33aba87c', 102),
(445, '4a522267487eb095fa5c32d081d2a3c56d931527', 103),
(446, 'a2bd79c71178dc83153c9dfdb827e9a75a8acb05', 100),
(447, '75738dacda60369d914e7f0eee5702e84bcde8ae', 102),
(448, '2f6ff351af560399ffd41a52e41179285f056e2e', 103),
(449, '73b44e74008575025ea3b2c7842dbe098a5bdad2', 100),
(450, 'aa1e6baa70b1227cc4f56bead1e511616f099bf7', 102),
(451, 'ea3a2a6e0e36fec6b911fb5da1bedd55f038bba4', 100),
(452, '6ff2731e6f7e0f3f43100caa0217054d608c732b', 102),
(453, 'b802212e8664fd4d1de2369a6bb5095ad6f8c6f8', 100),
(454, '3ec8bb5f7d01225baa478d1e134abcabba6eb071', 103),
(455, 'ce3c7b89e935ce45a9c7746f46cfdccdd08d8dbe', 102),
(456, '2e69f0e1933525e8ef1410a6a789ebb120923de3', 103),
(457, 'bf875c9c1c42614f59992c33839ae52ba766eb39', 102),
(458, 'f3b3205739fcbba761771f2bab9cbeafe620c410', 103),
(459, 'b84c32d03d6e4837acb8435a15aa607dc4219808', 100),
(460, 'b42900974222566c2ae1a3c42b19d26c13166b25', 103),
(461, 'fc9e6c7a1fa5595ac643c29308c3a19f4945d362', 102),
(462, 'cfca57714ef80f6c6f3650838c54f7b355de6936', 103),
(463, '7d1b873babc2e088fbbf80ed0c9db6323b0c251f', 100),
(464, '1a7699711d576bf78806882a431c3aa8fbd69c18', 103),
(465, '0b084d50195db8433992f8cbf86578dbb5dc549a', 100),
(466, '7baa28ece8b10da3c01e8861df155fc5cfe3654f', 102),
(467, '4bffcbae0a618578e9a8f2d76cbbe9496c49d1de', 100),
(468, 'c23e0e0b428b67411e2d39418d1e18de30ff0969', 102),
(469, 'a52616bf06a69ca9419bd0403367617e100e869c', 100),
(470, '6c5c5ae2c3acbef79836bd339faba629a03eb067', 102),
(471, '2a2bb4ccbaebf3e3b11c98cdb31545698509a1a8', 100),
(472, 'fd5c4f6833343b1b15e3b179b43425064a9a38b6', 100),
(473, 'ab3c20d516fd62c2412dfb8bd49ee20947d150c7', 102),
(474, 'e46594720106645c37f216e51c307f043b48d5cf', 100),
(475, 'f7db74d171ae38469e1f178be09d9e8adc5cf807', 102),
(476, 'a19fe8210640ae28d022febc190e336d5362d130', 100),
(477, '04c63db9c8df3a6a6cd8aa2c34758da8f059e969', 102),
(478, '20727be87c3a246b35f01b7600a4b71e06b6fe09', 100),
(479, '9e8988107af6fe0900302f55f6560f0a27b51479', 102),
(480, 'd9142d7d89e6a237d06a7a04bc8b4ecb1f197b04', 100),
(481, 'ad4196fb3a5364e7fc9ece7354de400a1d33d1e4', 102),
(482, 'c24c5e65d89cd8cc7a02896c637177dca8ddff16', 102),
(483, 'c2ff131dbbafb9a49d46ca7e3bae4b2b9597f573', 102),
(484, '30d375596e1cab0d2a2acde1b7b7b2c3455b7ee8', 102),
(485, '229d55ec385d03d81572b554bea7dfcc3cc59143', 102),
(486, '648e6265d6bfbcd1d7c7699017c1cd3c7eacfbcc', 103),
(487, '0fb2ac25379574d0be5f59f37ef76012b0b68c5d', 102),
(488, 'd795f73650045cdea96e38aafc816e83d4f4e7b5', 102),
(489, 'f2fd421240a6704639328f47281de631f0c4d973', 102),
(490, '3be469048d77e89769b5660c786d0929d86a01d0', 102),
(491, '62422194d1ce414d739d4bad168a85dcedc25608', 102),
(492, 'e57850aa880e08ee8a5c7466fa46ebe38bd48a07', 102),
(493, '73a25acc6f1b69df7a6ab51ca8dcd7c86c366899', 102),
(494, '61cb1c8e1e0ed02bc354b86788a5e94542c32081', 102),
(495, '4075b732a0e3c123d14d87dabd5285660aea5329', 102),
(496, 'ed3106f4418a83937d814ac29496a9d9764f9703', 102),
(497, '313015d49b9457de69eea7a7948b529ca08c5362', 103),
(498, 'd6b3eb04e9bf24cedc9349d81f9111afa3167816', 103),
(499, 'ebb84b0b75e1ecc3f988449722cfae358c31e8c5', 103),
(500, '927eacc4d0545cc79d12994bd643a5211ebb734e', 103),
(501, '15d8d021a3401f6e79520f5372b8b5a51885d270', 102),
(502, '6f3c86c24bf74be851f8fa3bd046f03a784f07f7', 102),
(503, '1905a80989f1ada3e87c959a5ea5059096faa8f6', 103);

-- --------------------------------------------------------

--
-- Table structure for table `user_chating1`
--

CREATE TABLE `user_chating1` (
  `id` int(11) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `receiver` varchar(100) NOT NULL,
  `content` varchar(255) NOT NULL,
  `status` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `msgcount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_chating2`
--

CREATE TABLE `user_chating2` (
  `id` int(11) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `receiver` varchar(100) NOT NULL,
  `content` varchar(255) NOT NULL,
  `status` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `msgcount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `block`
--
ALTER TABLE `block`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friend_request`
--
ALTER TABLE `friend_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `highest`
--
ALTER TABLE `highest`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `lockerroom`
--
ALTER TABLE `lockerroom`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_users1`
--
ALTER TABLE `my_users1`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `react`
--
ALTER TABLE `react`
  ADD PRIMARY KEY (`reactID`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id_fk` (`user_id`);

--
-- Indexes for table `user_chating1`
--
ALTER TABLE `user_chating1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_chating2`
--
ALTER TABLE `user_chating2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `block`
--
ALTER TABLE `block`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `friend_request`
--
ALTER TABLE `friend_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=342;

--
-- AUTO_INCREMENT for table `highest`
--
ALTER TABLE `highest`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lockerroom`
--
ALTER TABLE `lockerroom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `my_users1`
--
ALTER TABLE `my_users1`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `online`
--
ALTER TABLE `online`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `react`
--
ALTER TABLE `react`
  MODIFY `reactID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=331;

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=504;

--
-- AUTO_INCREMENT for table `user_chating1`
--
ALTER TABLE `user_chating1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;

--
-- AUTO_INCREMENT for table `user_chating2`
--
ALTER TABLE `user_chating2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

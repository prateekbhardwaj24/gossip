<!DOCTYPE html>
<html lang="en">

<head>
<!--    <meta charset="UTF-8">-->
    	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <title>Tutorial</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--    <link rel="stylesheet" href="header.css">-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/holder/2.9.4/holder.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>


</head>

<body style="background: #f2f7fb;">

    <div class="container mt-4">

<button class="btn btn-primary mt-2 d-flex ml-4" style="position: absolute;">Sign Up</button>
        <video width="100%;" height="auto;" controls autoplay style="z-index: -1; position: relative;">
            <source src="jay.mp4" type="video/mp4">
            <source src="jay.mp4" type="video/ogg">
            
<!--            <button class="btn btn-primary" style="position: absolute;">Sign Up</button>-->

        </video>

<div class="row">
   <div class="col-md-5 mt-3">
      <img src="person1.png" alt="" style="width: 300px; height: 300px;">
   </div>
    
    <div class="col-md-7">
       
        
    </div>
</div>


<div class="row">
   <div class="col-md-7">
      
       
   </div>
    
    <div class="col-md-5">
       <img src="person2.png" alt="" style="width: 300px; height: 300px;">
        
    </div>
    
    <div class="row">
       <div class="col-md-5">
           <img src="person3.png" alt="" style="width: 300px; height: 300px;">
       </div>
       <div class="col-md-7">
           
       </div>
        
    </div>
    
</div>


    </div>



</body>

</html>
